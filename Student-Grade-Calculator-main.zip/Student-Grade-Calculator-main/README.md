# Student Grade Calculator 🎓

A simple script to calculate grades dynamically based on scores.

## Features
- 📊 Compute average grades
- 🏆 Assign letter grades

## How to Use
1. Run `python grade_calculator.py`

## License
MIT License
